---
layout: post
title: Brazalete deportivo Craft
modified: 2015-02-23
categories: Brazalete-deportivo Accesorios mp3-correr
comments: true
---

Brazalete deportivo para llevar tu Mp3 o tu teléfono móvil mientras practicas tu deporte favorito, disponible en dos tallas, S/M y L/XL

![Elaphurus davidianus](http://i.imgur.com/x6119w9.jpg?1 "TSunstech Triton")

Características:

 - Neopreno
 - Ajustado
 - Dos tallas S/M y L/XL
 - Dedicado para practicar runnig
