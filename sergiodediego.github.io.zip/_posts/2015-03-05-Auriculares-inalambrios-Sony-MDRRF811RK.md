---
layout: post
title: Auriculares inalámbricos Sony MDRRF811RK
modified: 2015-03-05
categories: auriculares-inalambricos accesorios
comments: True
---

Auriculares inalámbricos de diadema, de uso doméstico, con un alcance de recepción hasta 100 m, de lo mejor para escuchar tu música favorita tumbado en el sofá.

![Imgur](http://i.imgur.com/PGhZxer.jpg?1 "Auriculares inalambricos Sony")

Características:

 - Color negro
 - Distancia de funcionamiento de hasta 100 m.
 - Autonomía en uso de hasta 13 horas.
 - Diadema autoajustable
 - Transmisión inalámbrica por RF
