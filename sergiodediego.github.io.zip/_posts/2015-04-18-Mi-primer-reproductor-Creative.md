---
layout: post
title: Mi primer reproductor MP3
modified: 2015-04-18
categories: reproductores-mp3 creative
comments: true
---
Hoy os vengo a contar cuál fue mi primer reproductor MP3, y no fue otro que el Creative MuVo TX FM de 128 MB.


![Creative MuVo](http://i.imgur.com/gRiJViR.jpg?1 "Creative")

Está claro que actualmente este reproductor no tendría mucho tirón, pero en su momento me pareció un gadget de gran calidad, no podía meter demasiada música, pero el sonido era bastante bueno, siempre he valorado la calidad de sonido de los productos Creative.

Como características, pues 128 megas de capacidad, radio FM, no necesitaba ningún cable por que se conectaba directamente al ordenador y funcionaba con pilas. El reproductor iba acompañado de cd con un software para instalar en el ordenador que permitía organizar tus archivos mp3 y facilitaba la transferencia de los archivo.

Ahora mismo lo veríamos como un producto del paleolítico pero que en su momento me amenizó muchos viajes en autobús al trabajo y solo lo consiguieron sustituir las siguiente generación de reproductores que llevaban integrada una pantalla y permitían reproducir vídeos.