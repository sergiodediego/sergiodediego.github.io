---
layout: post
title: Cargador portátil de 8.000mAh Aukey Blanco
modified: 2015-03-09
categories: Accesorios cargadores-portatiles
comments: true
---

Batería externa de 8.00mAh para cargar la batería de tu reproductor MP3, Smartphone o videoconsola portatil donde la necesites, no apto para disposivos de la marca Apple

![Imgur](http://i.imgur.com/EK59KWm.jpg?1 "Batería externa")

Características:

 - Tamaño reducido
 - Compatible con Android y Windows
 - Gran capacidad 8.000 mAh
