---
layout: post
title: Auriculares de botón Sennheiser CX 150
modified: 2015-03-22
categories: accesorios auriculares
comments: True
---
En esta ocasión analizamos uno auriculares que recomiendo personalmente, los vengo utilizando desde hace más de un año casi a diario, los tengo en la oficina, y el sonido y resistencia bastante buenos, sobre todo, si tenemos en cuenta que estamos hablando de unos auriculares que no llegan a los 15€

![Imgur](http://i.imgur.com/RXb2kRI.jpg?1 "Auriculares Sennheiser")

Características:

 - Frecuencia de auricular 20 - 20000 Hz;Tamaño de cable 1.2 m
 - Negro

