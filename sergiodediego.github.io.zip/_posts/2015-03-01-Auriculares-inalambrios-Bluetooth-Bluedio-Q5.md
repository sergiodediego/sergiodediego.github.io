---
layout: post
title: Auriculares inalámbricos Bluetooth Bluedio Q5
modified: 2015-03-01
categories: auriculares-inalambricos accesorios bluetooth
comments: true
---

Auriculares inalámbricos con tecnología Bluetooth, que te permitirán tanto mantener una conversación telefónica a través del móvil o escuchar tu música favorita desde tu MP3.

![Imgur](http://i.imgur.com/bg4oD4n.jpg?1 "Auriculares inalambricos")

Características:

 - Apto para Android, Blackberry, Windows e IOS
 - Distancia de funcionamiento de hasta 10 m.
 - Autonomía en uso de hasta 7 horas.
 - Soporta MP3
 - Color verde.
