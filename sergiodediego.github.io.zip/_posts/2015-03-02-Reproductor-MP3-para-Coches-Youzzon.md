---
layout: post
title: Reproductor MP3 para coches Youzzon con manos libres
modified: 2015-03-02
categories: reproductores-mp3 mp3-coches manos-libres bluetooth
comments: true
---

Reproductor MP3 para conectar directamente al enchufe del coche, de la marca Youzzon y poder escuchar tu música preferida a través de la radio del coche así como realizar y contestar llamadas, ya que dispone de tecnología Bluetooth para sincronizarlo con tu smartphone

![Imgur](http://i.imgur.com/cA0q0Si.jpg?1 "Reproductor MP3 para el coche")


Características:

 - Incluye mando a distancia
 - Con lector de tarjetas SD y SDHC
 - Permite conectar USB
 - Soporta MP3 y WMA
 - Tecnología Bluetooth
