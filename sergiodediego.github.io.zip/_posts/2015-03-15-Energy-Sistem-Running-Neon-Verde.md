---
layout: post
title: Energy Sistem Runing Neon Verde
modified: 2015-03-15
categories: mp3-correr reproductores-mp3
comments: true
---

Energy Sistem nos trae uno de los reproductores MP3 mejor adaptados para escuchar música mientras salimos a correr, ya que no solo cuenta con brazalete deportivo de neopreno, para ajustarlo al brazo, también dispone de un podómetro.

![Imgur](http://i.imgur.com/h1GIKHb.jpg?1 "Auriculares Reproductor mp3")

Características:

 - 8 GB de capacidad de almacenamiento
 - Diseñado para hacer deporte
 - Incluye brazalete deportivo
 - Con podómetro
 - Con radio FM
 - Formatos de audio: MP3, WAV, WMA, APE y FLAC
