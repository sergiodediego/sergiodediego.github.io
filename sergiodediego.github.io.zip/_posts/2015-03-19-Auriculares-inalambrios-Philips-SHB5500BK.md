---
layout: post
title: Auriculares inalámbricos Philips SHB5500BK
modified: 2015-03-19
categories: auriculares-inalambricos accesorios auriculares
comments: True
---

Auriculares inalámbricos Philips con tecnología Bluetooth y con posibilidad de contectar con tu smartphone para realizar llamadas y escuchar música

![Imgur](http://i.imgur.com/TWdHVAE.jpg?1 "Auriculares inalambricos Philips")

Características:

 - Transmisión mediante bluetooth
 - Micrófono integrado
 - Diadema autoajustable
 - Batería para escuchar música o hablar por teléfono durante 9 h.
