---
layout: post
title: Auriculares reproductor MP3 deportivo
modified: 2015-02-25
categories: mp3-correr reproductores-mp3
comments: true
---

Auriculares Reproductor MP3, sin cables, diseñados para escuchar música mientras practicas algún deporte al aire libre

![Imgur](http://i.imgur.com/wsOtf2Y.jpg? "Auriculares Reproductor mp3")

Características:

 - Diseñados para hacer deporte
 - Sin cables
 - Con soporte para tarjetas SD/TF de hasta 16 GB (no incluidas)
 - Batería de litio
 - Formatos de audio: MP3, WAV, WMA
