---
layout: post
title: Auriculares inalámbricos Philips SHC5100
modified: 2015-03-11
categories: auriculares-inalambricos accesorios auriculares
comments: True
---

Auriculares inalámbricos de diadema,  marca Philips, indicados para escuchar música en tu casa, ya que dispone de un transmisor FM.

![Imgur](http://i.imgur.com/OrY0CCQ.jpg?1 "Auriculares inalambricos Philips")

Características:

 - Transmisión inaĺámbrica FM
 - Funciona con pilas
 - Diadema autoajustable
 - Permite escuchar tu música desde otra habitación

