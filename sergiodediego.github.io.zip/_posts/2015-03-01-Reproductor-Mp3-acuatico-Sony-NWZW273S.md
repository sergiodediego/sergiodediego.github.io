---
layout: post
title: Reproductor Mp3 Acuático Sony NWZW273S Negro
modified: 2015-03-01
categories: Reproductores-MP3 MP3-Acuatico
comments: true
---

Reproductor Mp3 sumergible marca Sony, con 4 GB de capacidad, diseñado específicamente para utilizar mientras practicas natación.

![Imgur](http://i.imgur.com/raAqPDF.jpg?1 "Sony")

Características:

 - 4 GB de capacidad
 - Sumergible hasta 2 metros
 - Batería de litio con autonomía de hasta 20 h. y 8 h. de reproducción
 - Soporta MP3, WMA, AAC y LPCM
 - Dedicado para escuchar música mientras haces deporte, especialmente la natación.
