---
layout: post
title: Reproductor Mp3 Energy Sistem Aquatic 2 Fucsia
modified: 2015-03-12
categories: Reproductores-MP3 MP3-Acuatico
comments: true
---

Reproductor Mp3 sumergible marca energy Sistem, con 4 GB de capacidad, y un brazalete de neopreno para poder llevarlo en el brazo mientras nadas en la piscina o en la playa

![Imgur](http://i.imgur.com/yrS4ap6.jpg?1 "Energy Sistem Aquatic 2")

Características:

 - 4 GB de capacidad
 - Incorpora auriculáres acuáticos
 - Soporta MP3, WMA y WAV

