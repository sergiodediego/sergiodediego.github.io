---
layout: post
title: Auriculares inalámbricos Beats by Dr. Dre Solo2 Negros
Description: Análisis de los auriculares inalámbricos Beats by Dr. Dre Solo2
modified: 2016-02-14
categories: auriculares-inalambricos accesorios auriculares Beats
comments: True
---
### Resumen de las características:

 - Transmisión por WiFi y bluetooth
 - Micrófono integrado
 - Diadema ajustable

[Amazon](http://www.amazon.es/gp/product/B00TKGVBCG/ref=as_li_ss_tl?ie=UTF8&camp=3626&creative=24822&creativeASIN=B00TKGVBCG&linkCode=as2&tag=jerdelan-21 "Auriculares inalámbricos Beats by Dr. Dre Solo2 Negros"): 225,56€


***

### Análisis del producto:

Auriculares de diadema inalámbricos de la marca Beats by Dr. Dre Solo2 Wireless, conectalo con tu mp3 para escuchar tu música favorita o a tu smartphone para también realizar y recibir llamadas, permite moverte libremente hasta 9 metros sin cables y dispone de batería recargable con 12 horas de autonomía. Su excelente calidad de sonido lo convierte en uno de los mejores productos del mercado.

![Auriculares inalambricos Beats](http://i.imgur.com/LYQyetu.jpg?1 "Auriculares inalambricos Beats")




