---
layout: post
title: Reproductor Mp3 Acuático KK Electronics Negro
modified: 2015-03-16
categories: Reproductores-MP3 MP3-Acuatico
comments: true
---

Reproductor Mp3 impermeable con radio FM integrada y 4 GB de almacenamiento de memoria, ideal para realizar cualquier actividad acuática.

![Imgur](http://i.imgur.com/4S2vfsa.jpg?1 "Sony")

Características:

 - Batería con autonomía de entre 8 y 12 horas.
 - Memoria de 4 GB
 - Soporta MP3 y WMA
 - Incluye radio FM
