---
layout: post
title: Cargador portátil de 8.400mAh RAVPower Negro
modified: 2015-03-26
categories: Accesorios cargadores-portatiles
comments: true
---

Batería externa de 8.400mAh con dos salidas USB y compatible tanto para reproductores MP3 como para smartphones con SO Android, Windows y Blackberry, para productos Apple es necesario utilizar un adaptador (no incluido)

![Imgur](http://i.imgur.com/0BdLgsI.jpg?1 "Batería externa")

Características:

 - Tamaño reducido
 - Indicador LED de la energía disponible
 - Gran capacidad 8.400 mAh
 - Dos salidas USB
