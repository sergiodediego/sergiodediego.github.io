---
layout: post
title: Reproductor Mp3 sumergible Sunstech Triton
description: Análisis del reproductor Mp3 Sumergible Sunstech Triton
keywords: reproductor mp3 sumergible
modified: 2016-02-06
categories: Reproductores-MP3 MP3-Acuatico

comments: true
---
## Resumen de las características:

 - 4 GB de capacidad
 - Sumergible hasta 3 metros
 - Batería de litio con autonomía de hasta 10 h.
 - Soporta MP3 y WMA
 - Dedicado para escuchar música mientras haces deporte, especialmente la natación.
 - Color: negro con naranja


[Amazon](http://www.amazon.es/gp/product/B005DKJ40O/ref=as_li_ss_tl?ie=UTF8&camp=3626&creative=24822&creativeASIN=B005DKJ40O&linkCode=as2&tag=jerdelan-21 "Reproductor Mp3 Sumergible Sunstech Triton"): 37,40€


***

## Análisis del producto:

Reproductor Mp3 sumergible Sunstech Triton con 4 GB de capacidad, especialmente diseñado para utilizar y escuchar toda tu música mientras nadas y buceas, ya que está se encuentra integrado dentro de los auriculares, y su diseño permite para que se pueda sumergir hasta 3 metros, por lo que no hay ningún problema en que lo puedas utilizar en una piscina.

La ausencia de cables, facilita que se pueda utilizar, no solo nadando, sino también corriendo, caminando, o practicando algún otro deporte, aunque realmente está fabricado pensando en los nadadores y que puedan sumergirse tranquilamente escuchando música.

![Reproductor Mp3 Sumergible Sunstech Triton](http://i.imgur.com/6P3A3KU.jpg?1 "TSunstech Triton")

Otro aspecto interesante de este reproductor, aunque casi se podría considerar más como una accesorio del mismo, es que dispone de hasta 12 almohadillas de silicona distintas, las cuales incluyen protección hermética del auricular, que nos puede venir muy bien según el tipo de conducto auditivo tengamos, y más teniendo en cuenta, que los auriculares tienen que soportar inmersiones de hasta 3 metros y que, como todos sabemos, es muy incomodo que nos entre agua en el oido.

En cuanto a la batería, de litio, estamos hablando de 180mAh, que nos va a permitir escuchar música durante unas 10 horas, nos va a permitir llevarnos y utilizar durante un día entero en la piscina sin tener que preocuparnos de llevar baterías externas.

Para poder realizar la transferencia de nuestros archivos dispone de una cable de USB 2.0, lo que nos garantizará una notable velocidad de transferencia.

En general, viendo los comentarios de algunos compradores, le dan una nota media de 3,4 sobre 5, estamos ante un reproductor bastante resulton, alguna queja sobre el material o algún problema a la hora de utilizar con el gorro de baño a la hora de utilizarlo en la piscina, pero en general tiene buenos comentarios que junto con un precio no demasiado elevado lo convierte en una muy buena alternativa si te gusta escuchar música mientras nadas o sales a correr.

