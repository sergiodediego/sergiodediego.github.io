---
layout: post
title: Reproductor Mp3 Acuático AGPTek Waterproof
description: Análisis del Reproductor acuático AGPTek Waterproof
modified: 2016-02-14
categories: reproductores-mp3 mp3-acuatico
comments: true
---
### Resumen de las características:

 - Batería de litio con autonomía de entre 12 y 14 horas.
 - Memoria de 4 GB
 - Soporta MP3
 - Incluye radio FM


***

### Análisis del producto:

Ahora que llega el verano, se abren las piscinas y empezamos a planear en qué playita pasar esos pocos días de vacaciones que podremos disfrutar, os presento un nuevo reproductor MP3 para escuchar toda nuestra música, mientras nadamos en la piscina o en la playa.

Estamos hablando de AGPTek 4 GB IPX8 Waterproof, reproductor deportivo, pero orientado sobre todo a la natación, ya que es resistente al agua hasta una profundidad de 3 metros.

![Reproductor Mp3 Acuático AGPTek Waterproof](http://i.imgur.com/7W9YA50.jpg?1 "AGPTek")




