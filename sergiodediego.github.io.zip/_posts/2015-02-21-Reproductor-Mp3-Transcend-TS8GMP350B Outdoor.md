---
layout: post
title: Reproductor Mp3 Transcend
modified: 2015-02-21
categories: Reproductores-MP3
comments: true
---

Reproductor Mp3 Transcend TS8GMP350B de 8 GB.

![Elaphurus davidianus](http://i.imgur.com/c9KvbN8.jpg?1 "Transcend TS8GMP350B")

Características:

 - Incluye radio
 - Pantalla de 1,0"
 - Grabación de voz
 - Soporta MP3, WMA, WAV
 - Nuevas características incluyen Fitness Tracker y grabación inteligente

