---
layout: post
title: Cargador portátil de 3.000mAh Aukey Negro
modified: 2015-03-02
categories: Accesorios cargadores-portatiles
comments: true
---

Batería externa de 3.00mAh para cargar la batería de tu reproductor MP3, Smartphone o videoconsola portatil donde la necesites.

![Imgur](http://i.imgur.com/TqhOxc6.jpg?1 "Batería externa")

Características:

 - Tamaño reducido
 - Compatible con Android, IOS y Windows
 - Añade hasta 70 horas de reproducción de música
