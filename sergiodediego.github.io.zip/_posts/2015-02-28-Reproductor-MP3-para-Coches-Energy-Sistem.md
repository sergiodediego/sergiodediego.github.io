---
layout: post
title: Reproductor MP3 para coches Energy Sistem
modified: 2015-02-28
categories: reproductores-mp3 mp3-coches
comments: true
---

Hoy os traemos un reproductor MP3 para conectar directamente al enchufe del coche, de la marca Energy Sistem, y poder escuchar tu música preferida a través de la radio del coche.

![Imgur](http://i.imgur.com/PdMKkB8.jpg?1"Reproductor MP3 para el coche")


Características:

 - Incluye mando a distancia
 - Con lector de tarjetas SD y SDHC
