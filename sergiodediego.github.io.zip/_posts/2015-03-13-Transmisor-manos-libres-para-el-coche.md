---
layout: post
title: Transmisor manos libres para el coche
modified: 2015-03-13
categories: mp3-coches manos-libres bluetooth
comments: true
---

Hoy traemos un kit manos libres para poder utilizar el teléfono móvil en el coche que también tiene función MP3, permite escuchar tu música favorita mediante una tarjeta SD o un USB

![Imgur](http://i.imgur.com/qLAVJyP.jpg?1 "Reproductor MP3 para el coche")


Características:

 - Con mando a distancia
 - Incluye lector de tarjetas SD y USB
 - Formatos de audio MP3 y WMA
 - Alimentación a través del mechero
 - Tecnología Bluetooth

